function result=FE_basis_local_fun_2D(x,y,vertices,basis_type,basis_index,basis_der_x,basis_der_y)
if basis_type==201||basis_type==202

J11=vertices(1,2)-vertices(1,1);%x,yͨ���Ǹ�˹���ֵ㣬���ڱ�����
J12=vertices(1,3)-vertices(1,1);%vertices����ȷ���ֲ��������������ض��ĵ�Ԫ��ֵ�Ƕ�ֵ
J21=vertices(2,2)-vertices(2,1);
J22=vertices(2,3)-vertices(2,1);
Jdet=J11*J22-J12*J21;
xh=(J22*(x-vertices(1,1))-J12*(y-vertices(2,1)))/Jdet;
yh=(-J21*(x-vertices(1,1))+J11*(y-vertices(2,1)))/Jdet;
if         basis_der_x==0 && basis_der_y==0
           result=triangular_reference_basis(xh,yh,basis_type,basis_index,0,0);          
    elseif basis_der_x==1 && basis_der_y==0
           result=(J22*triangular_reference_basis(xh,yh,basis_type,basis_index,1,0)...
                  +(-J21)*triangular_reference_basis(xh,yh,basis_type,basis_index,0,1))/Jdet;              
    elseif basis_der_x==0 && basis_der_y==1
           result=((-J12)*triangular_reference_basis(xh,yh,basis_type,basis_index,1,0)...
                  +(J11)*triangular_reference_basis(xh,yh,basis_type,basis_index,0,1))/Jdet;             
    elseif basis_der_x==2 && basis_der_y==0
           result=(J22/Jdet)^2*triangular_reference_basis(xh,yh,basis_type,basis_index,2,0)...
                  +2*(-J21*J22/Jdet/Jdet)*triangular_reference_basis(xh,yh,basis_type,basis_index,1,1)...
                  +(J21/Jdet)^2*triangular_reference_basis(xh,yh,basis_type,basis_index,0,2);
    elseif basis_der_x==0 && basis_der_y==2
           result=(J12/Jdet)^2*triangular_reference_basis(xh,yh,basis_type,basis_index,2,0)...
                  +2*(-J12*J11/Jdet/Jdet)*triangular_reference_basis(xh,yh,basis_type,basis_index,1,1)...
                  +(J11/Jdet)^2*triangular_reference_basis(xh,yh,basis_type,basis_index,0,2);
    elseif basis_der_x==1 && basis_der_y==1
           result=(-J12*J22/Jdet/Jdet)*triangular_reference_basis(xh,yh,basis_type,basis_index,2,0)...
                  +(-J12*(-J21)/Jdet/Jdet)*triangular_reference_basis(xh,yh,basis_type,basis_index,1,1)...
                  +(J11*J22/Jdet/Jdet)*triangular_reference_basis(xh,yh,basis_type,basis_index,1,1)...
                  +(J11*(-J21)/Jdet/Jdet)*triangular_reference_basis(xh,yh,basis_type,basis_index,0,2);%0,2���0,1��������
 end

elseif basis_type==241||basis_type==242
h1=vertices(1,2)-vertices(1,1);%x,yͨ���Ǹ�˹���ֵ㣬���ڱ�����vertices����ȷ���ֲ��������������ض��ĵ�Ԫ��ֵ�Ƕ�ֵ
h2=vertices(2,4)-vertices(2,1);
xh=(2*x-2*vertices(1,1)-h1)/h1;
yh=(2*y-2*vertices(2,1)-h2)/h2;
if         basis_der_x==0 && basis_der_y==0
           result=rectangular_reference_basis(xh,yh,basis_type,basis_index,0,0);          
    elseif basis_der_x==1 && basis_der_y==0
           result=2/h1*rectangular_reference_basis(xh,yh,basis_type,basis_index,1,0);              
    elseif basis_der_x==0 && basis_der_y==1
           result=2/h2*rectangular_reference_basis(xh,yh,basis_type,basis_index,0,1);             
    elseif basis_der_x==2 && basis_der_y==0
           result=2/h1*(rectangular_reference_basis(xh,yh,basis_type,basis_index,2,0)*2/h1+rectangular_reference_basis(xh,yh,basis_type,basis_index,1,1)*0);
    elseif basis_der_x==0 && basis_der_y==2
           result=2/h2*(rectangular_reference_basis(xh,yh,basis_type,basis_index,1,1)*0+rectangular_reference_basis(xh,yh,basis_type,basis_index,0,2)*2/h2);
    elseif basis_der_x==1 && basis_der_y==1
           result=4/(h1*h2)*rectangular_reference_basis(xh,yh,basis_type,basis_index,1,1);
 end       
end

