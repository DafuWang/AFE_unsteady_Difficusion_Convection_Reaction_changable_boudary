function error=computer_infinite_error_2D(weak_solution,Tb_test,T,P,Gauss_nodes_number_2D,basis_type,nn)
error=0;
[Gauss_weights_reference_2D,Gauss_nodes_reference_2D]=generate_Gauss_reference_rectangular(Gauss_nodes_number_2D);
for n=1:size(T,2)
    vertices=P(:,T(:,n));%�����
    weak_solution_in_node_of_element=weak_solution(Tb_test(:,n));%ȡ��Ԫn�����е�����ֵ
    
    [Gauss_weights,Gauss_nodes]=generate_Gauss_local_rectangular(Gauss_weights_reference_2D,Gauss_nodes_reference_2D,vertices);

        r=max(abs(exact_order_solution_2D(0,0,Gauss_nodes(:,1),Gauss_nodes(:,2),nn)-...
              weak_solution_in_local(weak_solution_in_node_of_element,Gauss_nodes(:,1),Gauss_nodes(:,2),vertices,basis_type,0,0)));
        if r>error
           error=r; 
        end
   
end
