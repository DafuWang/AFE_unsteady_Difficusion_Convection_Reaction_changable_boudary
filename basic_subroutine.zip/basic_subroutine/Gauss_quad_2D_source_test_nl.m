function int_value=Gauss_quad_2D_source_test_nl(function_source,...
                                                                 weak_solution_1,basis_type_trial_ln_1,basis_der_x_trial_ln_1,basis_der_y_trial_ln_1,...
                                                                 weak_solution_2,basis_type_trial_ln_2,basis_der_x_trial_ln_2,basis_der_y_trial_ln_2,...
                                                                 Gauss_weights,Gauss_nodes,vertices,...
                                                                 basis_type_test,basis_index,basis_der_x_test,basis_der_y_test)

            
                                       

                                        
int_value=0;
for k=1:length(Gauss_nodes) 
    int_value=int_value+...%ʵ���ۼ�.
              Gauss_weights(k)*...%��˹��Ȩϵ��
              feval(function_source,Gauss_nodes(k,1),Gauss_nodes(k,2),weak_solution_1,weak_solution_2,vertices,basis_type_trial_ln_1,basis_der_x_trial_ln_1,basis_der_y_trial_ln_1,basis_type_trial_ln_2,basis_der_x_trial_ln_2,basis_der_y_trial_ln_2)*...
              FE_basis_local_fun_2D(Gauss_nodes(k,1),Gauss_nodes(k,2),vertices,basis_type_test,basis_index,basis_der_x_test,basis_der_y_test);%���Ի�����
end

