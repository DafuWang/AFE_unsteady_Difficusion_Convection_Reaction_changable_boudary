function int_value=Gauss_quad_2D_exact_weak_solution_t(weak_solution_in_node_element,Gauss_weights,Gauss_nodes,vertices,basis_type,basis_der_x,basis_der_y,nn,t)
int_value=0;
for k=1:length(Gauss_weights) 
    int_value=int_value+...
              Gauss_weights(k)*...%��˹��Ȩϵ��
              (exact_order_solution_2D_t(basis_der_x,basis_der_y,Gauss_nodes(k,1),Gauss_nodes(k,2),t,nn)-...%ǿ��
              weak_solution_in_local(weak_solution_in_node_element,Gauss_nodes(k,1),Gauss_nodes(k,2),vertices,basis_type,basis_der_x,basis_der_y))^(2);%����
end
