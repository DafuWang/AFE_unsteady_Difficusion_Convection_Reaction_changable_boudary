function result=FE_basis_local_rectangular_2D(x,y,vertices,basis_type,basis_index,basis_der_x,basis_der_y)
h1=vertices(1,2)-vertices(1,1);%x,yͨ���Ǹ�˹���ֵ㣬���ڱ�����vertices����ȷ���ֲ��������������ض��ĵ�Ԫ��ֵ�Ƕ�ֵ
h2=vertices(2,4)-vertices(2,1);
xh=(2*x-2*vertices(1,1)-h1)/h1;
yh=(2*y-2*vertices(2,1)-h2)/h2;
if         basis_der_x==0 && basis_der_y==0
           result=rectangular_reference_basis(xh,yh,basis_type,basis_index,0,0);          
    elseif basis_der_x==1 && basis_der_y==0
           result=2/h1*rectangular_reference_basis(xh,yh,basis_type,basis_index,1,0);              
    elseif basis_der_x==0 && basis_der_y==1
           result=2/h2*triangular_reference_basis(xh,yh,basis_type,basis_index,0,1);             
    elseif basis_der_x==2 && basis_der_y==0
           result=2/h1*(rectangular_reference_basis(xh,yh,basis_type,basis_index,2,0)*2/h1+rectangular_reference_basis(xh,yh,basis_type,basis_index,1,1)*0);
    elseif basis_der_x==0 && basis_der_y==2
           result=2/h2*(rectangular_reference_basis(xh,yh,basis_type,basis_index,1,1)*0+rectangular_reference_basis(xh,yh,basis_type,basis_index,0,2)*2/h2);
    elseif basis_der_x==1 && basis_der_y==1
           result=4/(h1*h2)*rectangular_reference_basis(xh,yh,basis_type,basis_index,1,1);
 end



