function [Gauss_coefficient_local_rectangular,Gauss_point_local_rectangular]=generate_Gauss_local_rectangular(Gauss_coefficient_reference_rectangular,Gauss_point_reference_rectangular,vertices_rectangular)

x1=vertices_rectangular(1,1);
y1=vertices_rectangular(2,1);
x2=vertices_rectangular(1,2);
% y2=vertices_rectangular(2,2);
% x3=vertices_rectangular(1,3);
% y3=vertices_rectangular(2,3);
% x4=vertices_rectangular(1,4);
y4=vertices_rectangular(2,4);
h1=x2-x1;h2=y4-y1;
Jacobi=abs(1/4*h1.*h2);
Gauss_coefficient_local_rectangular=Gauss_coefficient_reference_rectangular*Jacobi;
Gauss_point_local_rectangular(:,1)=x1+h1/2.*Gauss_point_reference_rectangular(:,1)+h1/2;
Gauss_point_local_rectangular(:,2)=y1+h2/2.*Gauss_point_reference_rectangular(:,2)+h2/2;