function int_val=Gauss_quad_for_line_test_ph_t(function_cp,Gauss_weights_reference_1D,Gauss_nodes_reference_1D,boundary_nodes_coodinate,vertices,basis_type,basis_index,basis_der_x,basis_der_y,norm_section,t,nn)
%boundary_nodes_coodinate(2,1)�����߽��1���ڵ��y����    

int_val=0;
%%
if (boundary_nodes_coodinate(2,1)==boundary_nodes_coodinate(2,2))%��ʾ���±߽磬���������
end_coordinate(1,1)=min(boundary_nodes_coodinate(1,1),boundary_nodes_coodinate(1,2));
end_coordinate(1,2)=max(boundary_nodes_coodinate(1,1),boundary_nodes_coodinate(1,2));    
[Gauss_weights,Gauss_nodes]=generate_Gauss_local_1D(Gauss_weights_reference_1D,Gauss_nodes_reference_1D,end_coordinate);
 for k=1:length(Gauss_nodes)
   int_val=int_val+Gauss_weights(k)*feval(function_cp,Gauss_nodes(k),boundary_nodes_coodinate(2,2),t,norm_section,nn)*FE_basis_local_fun_2D(Gauss_nodes(k),boundary_nodes_coodinate(2,2),vertices,basis_type,basis_index,basis_der_x,basis_der_y);
 
 end
 
 
%% 
elseif (boundary_nodes_coodinate(1,1)==boundary_nodes_coodinate(1,2))%��ʾ���ұ߽磬���������

end_coordinate(1,1)=min(boundary_nodes_coodinate(2,1),boundary_nodes_coodinate(2,2));%���зֱ��ʾ����ֵ
end_coordinate(1,2)=max(boundary_nodes_coodinate(2,1),boundary_nodes_coodinate(2,2));    
[Gauss_weights,Gauss_nodes]=generate_Gauss_local_1D(Gauss_weights_reference_1D,Gauss_nodes_reference_1D,end_coordinate); 
for k=1:1:length(Gauss_nodes)
   int_val=int_val+Gauss_weights(k)*feval(function_cp,boundary_nodes_coodinate(1,1),Gauss_nodes(k),t,norm_section,nn)*FE_basis_local_fun_2D(boundary_nodes_coodinate(1,1),Gauss_nodes(k),vertices,basis_type,basis_index,basis_der_x,basis_der_y); 
   
end
%% 
else
 end_coordinate(1,1)=min(boundary_nodes_coodinate(1,1),boundary_nodes_coodinate(1,2));
 end_coordinate(1,2)=max(boundary_nodes_coodinate(1,1),boundary_nodes_coodinate(1,2));     
 [Gauss_weights,Gauss_nodes]=generate_Gauss_local_1D(Gauss_weights_reference_1D,Gauss_nodes_reference_1D,end_coordinate);
 slope=(boundary_nodes_coodinate(2,1)-boundary_nodes_coodinate(2,2))/(boundary_nodes_coodinate(1,1)==boundary_nodes_coodinate(1,2));
 coe_ds_dx=sqrt(1+slope^2);
for k=1:1:length(Gauss_nodes)
    x=Gauss_nodes(k);
    y=slope*(x-boundary_nodes_coodinate(1,1))+boundary_nodes_coodinate(2,1);
    int_val=int_val+Gauss_weights(k)*coe_ds_dx*feval(function_cp,x,y,t,norm_section,nn)*FE_basis_local_fun_2D(x,y,vertices,basis_type,basis_index,basis_der_x,basis_der_y); 
end


end

