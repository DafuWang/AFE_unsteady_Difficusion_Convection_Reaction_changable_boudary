function r=triangular_reference_basis(xh,yh,basis_type,basis_index,derivative_degree_x,derivative_degree_y)

if basis_type==202
    
    if derivative_degree_x==0&&derivative_degree_y==0
        
        if basis_index==1
            r=1-3*xh-3*yh+2*xh.^2+2*yh.^2+4*xh.*yh;
        elseif basis_index==2
            r=2*xh.^2-xh;
        elseif basis_index==3
            r=2*yh.^2-yh;
        elseif basis_index==4
            r=4*xh-4*xh.^2-4*xh.*yh;
        elseif basis_index==5
            r=4*xh.*yh;
        elseif basis_index==6
            r=4*yh-4*yh.^2-4*xh.*yh;
        end
             
    elseif derivative_degree_x==1&&derivative_degree_y==0
 
        if basis_index==1
            r=-3+4*xh+4*yh;
        elseif basis_index==2
            r=4*xh-1;
        elseif basis_index==3
            r=0;
        elseif basis_index==4
            r=4-8*xh-4*yh;
        elseif basis_index==5
            r=4*yh;
        elseif basis_index==6
            r=-4*yh;
        end           

                      
    elseif derivative_degree_x==0&&derivative_degree_y==1
            
        if basis_index==1
            r=-3+4*yh+4*xh;
        elseif basis_index==2
            r=0;
        elseif basis_index==3
            r=4*yh-1;
        elseif basis_index==4
            r=-4*xh;
        elseif basis_index==5
            r=4*xh;
        elseif basis_index==6
            r=4-8*yh-4*xh;
        end
      
    elseif derivative_degree_x==2&&derivative_degree_y==0  
        
        if basis_index==1
            r=4;
        elseif basis_index==2
            r=4;
        elseif basis_index==3
            r=0;
        elseif basis_index==4
            r=-8;
        elseif basis_index==5
            r=0;
        elseif basis_index==6
            r=0;
        end

    elseif derivative_degree_x==0&&derivative_degree_y==2 

        if basis_index==1
            r=4;
        elseif basis_index==2
            r=0;
        elseif basis_index==3
            r=4;
        elseif basis_index==4
            r=0;
        elseif basis_index==5
            r=0;
        elseif basis_index==6
            r=-8;
        end

    elseif derivative_degree_x==1&&derivative_degree_y==1 

        if basis_index==1
            r=4;
        elseif basis_index==2
            r=0;
        elseif basis_index==3
            r=0;
        elseif basis_index==4
            r=-4;
        elseif basis_index==5
            r=4;
        elseif basis_index==6
            r=-4;
        end 
      
    end

%% 
elseif basis_type==201

    if derivative_degree_x==0&&derivative_degree_y==0
        
        if basis_index==1
            r=1-xh-yh;
            r1=r;
        elseif basis_index==2
            r=xh;
            r2=r;
        elseif basis_index==3
            r=yh;
            r3=r;
        end

    elseif derivative_degree_x==1&&derivative_degree_y==0
        
        if basis_index==1
            r=-1;
        elseif basis_index==2
            r=1;
        elseif basis_index==3
            r=0;
        end

    elseif derivative_degree_x==0&&derivative_degree_y==1
        
        if basis_index==1
            r=-1;
        elseif basis_index==2
            r=0;
        elseif basis_index==3
            r=1;
        end
        
    end
       
end