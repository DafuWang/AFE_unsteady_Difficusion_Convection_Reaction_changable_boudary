function r=rectangular_reference_basis(xh,yh,basis_type,basis_index,derivative_degree_x,derivative_degree_y)

if basis_type==242
 a=[0,0,0,0,0,0,0,0,1;0,0,0,0,0,0.500000000000000,0,-0.500000000000000,0;0,0,0,0,-0.500000000000000,0,0.500000000000000,0,0;0.250000000000000,-0.250000000000000,0.250000000000000,-0.250000000000000,0,0,0,0,0;0,0,0,0,0,0.500000000000000,0,0.500000000000000,-1;0,0,0,0,0.500000000000000,0,0.500000000000000,0,-1;-0.250000000000000,-0.250000000000000,0.250000000000000,0.250000000000000,0.500000000000000,0,-0.500000000000000,0,0;-0.250000000000000,0.250000000000000,0.250000000000000,-0.250000000000000,0,-0.500000000000000,0,0.500000000000000,0;0.250000000000000,0.250000000000000,0.250000000000000,0.250000000000000,-0.500000000000000,-0.500000000000000,-0.500000000000000,-0.500000000000000,1];  
  
%     a=[0,0,0,0,0,0,0,0,1;
%      0,0,0,0,0,0.5,0,-0.5,0;
%      0,0,0,0,-0.5,0,0.5,0,0;
%      0.25,-0.25,0.25,-0.25,0,0,0,0,0;
%      0,0,0,0,0,0.5,0,0.5,-1;
%      0,0,0,0,0.5,0,0.5,0,-1;
%      -0.25,-0.25,0.25,0.25,0.5,0,-0.5,0,0;
%      -0.25,0.25,0.25,-0.25,0,-0.5,0,0.5,0;
%      0.25,0.25,0.25,0.25,-0.5,-0.5,-0.5,-0.5,1];
    i=basis_index;
    if derivative_degree_x==0&&derivative_degree_y==0        
     r=a(1,i)+a(2,i)*xh+a(3,i)*yh+a(4,i)*xh.*yh+a(5,i)*xh.*xh+a(6,i)*yh.*yh+a(7,i)*xh.*xh.*yh+a(8,i)*yh.*yh.*xh+a(9,i)*xh.*xh.*yh.*yh;             
    
    elseif derivative_degree_x==1&&derivative_degree_y==0
     r=0+     a(2,i)*1+ a(3,i)*0+ a(4,i)*1*yh+  a(5,i)*2*xh+  a(6,i)*0+     a(7,i)*2*xh.*yh+  a(8,i)*yh.*yh.*1+ a(9,i)*2*xh.*yh.*yh;                               
    elseif derivative_degree_x==0&&derivative_degree_y==1
     r=0+     a(2,i)*0+ a(3,i)*1+ a(4,i)*xh.*1+ a(5,i)*0+     a(6,i)*2*yh+  a(7,i)*xh.*xh.*1+ a(8,i)*2*yh.*xh+  a(9,i)*xh.*xh.*2*yh;          
    elseif derivative_degree_x==2&&derivative_degree_y==0  
     r=0+     a(2,i)*0+ a(3,i)*0+ a(4,i)*0+     a(5,i)*2+     a(6,i)*0+     a(7,i)*2*yh+      a(8,i)*0+         a(9,i)*2*yh.*yh;
    elseif derivative_degree_x==0&&derivative_degree_y==2 
     r=0+     a(2,i)*0+ a(3,i)*0+ a(4,i)*0+     a(5,i)*0+     a(6,i)*2+     a(7,i)*0+         a(8,i)*2*xh+      a(9,i)*xh.*xh*2;
    elseif derivative_degree_x==1&&derivative_degree_y==1 
     r=0+     a(2,i)*0+ a(3,i)*0+ a(4,i)*1*1+   a(5,i)*0+     a(6,i)*0+     a(7,i)*2*xh.*1+   a(8,i)*2*yh.*1+   a(9,i)*2*xh.*2*yh;      
    end

%% 
elseif basis_type==241

    if derivative_degree_x==0&&derivative_degree_y==0
        
        if basis_index==1
            r=(1-xh-yh+xh.*yh)/4;
        elseif basis_index==2
            r=(1+xh-yh-xh.*yh)/4;
        elseif basis_index==3
            r=(1+xh+yh+xh.*yh)/4;
        elseif basis_index==4
            r=(1-xh+yh-xh.*yh)/4;            
        end

    elseif derivative_degree_x==1&&derivative_degree_y==0
        
        if basis_index==1
            r=-1/4+yh/4;
        elseif basis_index==2
            r=1/4-yh/4;
        elseif basis_index==3
            r=1/4+yh/4;
        elseif basis_index==4
            r=-1/4-yh/4;            
        end

    elseif derivative_degree_x==0&&derivative_degree_y==1
        
        if basis_index==1
            r=-1/4+xh/4;
        elseif basis_index==2
            r=-1/4-xh/4;
        elseif basis_index==3
            r=1/4+xh/4;
        elseif basis_index==4
            r=1/4-xh/4;            
        end
        
    elseif derivative_degree_x==1&&derivative_degree_y==1
        
        if basis_index==1
            r=1/4;
        elseif basis_index==2
            r=-1/4;
        elseif basis_index==3
            r=1/4;
        elseif basis_index==4
            r=-1/4;            
        end    
       
    end
       
end