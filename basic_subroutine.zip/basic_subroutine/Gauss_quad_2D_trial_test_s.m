function int_value=Gauss_quad_2D_trial_test_s(coe_fun,Gauss_weights,Gauss_nodes,vertices,...
                                            basis_type_trial,alpha,basis_der_x_trial,basis_der_y_trial,...
                                            basis_type_test,beta,basis_der_x_test,basis_der_y_test)
                                                                                                                      
int_value=0;
for k=1:length(Gauss_nodes)


    int_value=int_value+...%ʵ���ۼ�.
              Gauss_weights(k)*...%��Ԫ�ϵĸ�˹��Ȩϵ��
              feval(coe_fun,Gauss_nodes(k,1),Gauss_nodes(k,2))*...%����ϵ��.
              FE_basis_local_fun_2D(Gauss_nodes(k,1),Gauss_nodes(k,2),vertices,basis_type_trial,alpha,basis_der_x_trial,basis_der_y_trial)*...%��̽������
              FE_basis_local_fun_2D(Gauss_nodes(k,1),Gauss_nodes(k,2),vertices,basis_type_test,beta,basis_der_x_test,basis_der_y_test);%���Ի�����            
end

