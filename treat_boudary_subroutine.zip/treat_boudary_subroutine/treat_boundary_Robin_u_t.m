function [A,b]=treat_boundary_Robin_u_t(function_cq,function_Robin_cr,A,b,boundary_edges,basis_type,Gauss_nodes_number_1D,T,P,Pb_test,...                            
                         Tb_trial,Nlb_trial,basis_trial_der_x,basis_trial_der_y,...
                         Tb_test,Nlb_test,basis_test_der_x,basis_test_der_y,t)
nb_FE_vector_field=size(Pb_test,2);
nbe=size(boundary_edges,2);%������߽������
for k=1:nbe
    if(boundary_edges(1,k)==-3)
        n=boundary_edges(3,k);%ȷ���߽�����ĸ��Ԫ
        vertices=P(:,T(:,n));%ȡ��Ԫ�������,����ȷ�����Ե�Ԫ�Ͼֲ�������
        boundary_nodes_coodinate=P(:,boundary_edges(4:5,k));%ȡ�߽�߽ڵ����꣬�����ж�
        boundary_edges_normal_section=boundary_edges(6:7,k);%��������
        [Gauss_weights_reference_1D,Gauss_nodes_reference_1D]=generate_Gauss_reference_1D(Gauss_nodes_number_1D);        
      for beta=1:Nlb_test       
         w1=Gauss_quad_for_line_test_ph_t(function_cq,Gauss_weights_reference_1D,Gauss_nodes_reference_1D,boundary_nodes_coodinate,vertices,basis_type,beta,basis_test_der_x,basis_test_der_y,boundary_edges_normal_section,t,1);    
         b(Tb_test(beta,n),1)=b(Tb_test(beta,n),1)+w1;
         w2=Gauss_quad_for_line_test_ph_t(function_cq,Gauss_weights_reference_1D,Gauss_nodes_reference_1D,boundary_nodes_coodinate,vertices,basis_type,beta,basis_test_der_x,basis_test_der_y,boundary_edges_normal_section,t,2);    
         b(nb_FE_vector_field+Tb_test(beta,n),1)=b(nb_FE_vector_field+Tb_test(beta,n),1)+w2;
         
      end
      
      for alph=1:Nlb_trial
          for beta=1:Nlb_test
              R=Gauss_quad_for_line_trial_test_rh_t(function_Robin_cr,Gauss_weights_reference_1D,Gauss_nodes_reference_1D,boundary_nodes_coodinate,vertices,basis_type,alph,basis_trial_der_x,basis_trial_der_y,beta,basis_test_der_x,basis_test_der_y,t);
              A(Tb_test(beta,n),Tb_trial(alph,n))= A(Tb_test(beta,n),Tb_trial(alph,n))+R;
              A(nb_FE_vector_field+Tb_test(beta,n),nb_FE_vector_field+Tb_trial(alph,n))= A(nb_FE_vector_field+Tb_test(beta,n),nb_FE_vector_field+Tb_trial(alph,n))+R;              
          end
      end
      
      
      
    end
end


