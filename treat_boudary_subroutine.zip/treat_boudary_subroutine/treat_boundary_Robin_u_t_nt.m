function [A,b]=treat_boundary_Robin_u_t_nt(function_cq,function_Robin_cr,A,b,boundary_edges,basis_type,Gauss_nodes_number_1D,T,P,Pb_test,...                            
                         Tb_trial,Nlb_trial,basis_trial_der_x,basis_trial_der_y,...
                         Tb_test,Nlb_test,basis_test_der_x,basis_test_der_y,t)
Nb=size(Pb_test,2);
nbe=size(boundary_edges,2);%������߽������
for k=1:nbe
    if(boundary_edges(1,k)==-3)
        n=boundary_edges(3,k);%ȷ���߽�����ĸ��Ԫ
        vertices=P(:,T(:,n));%ȡ��Ԫ�������,����ȷ�����Ե�Ԫ�Ͼֲ�������
        boundary_nodes_coodinate=P(:,boundary_edges(4:5,k));%ȡ�߽�߽ڵ�����
        normal_section=boundary_edges(6:7,k);%��������
        tangential_section=boundary_edges(8:9,k);%��������
        
        [Gauss_weights_reference_1D,Gauss_nodes_reference_1D]=generate_Gauss_reference_1D(Gauss_nodes_number_1D);        
      for beta=1:Nlb_test       
         w1=Gauss_quad_for_line_test_ph_t_nt(function_cq,Gauss_weights_reference_1D,Gauss_nodes_reference_1D,boundary_nodes_coodinate,vertices,basis_type,beta,basis_test_der_x,basis_test_der_y,1,normal_section(1,1),t)+...
            Gauss_quad_for_line_test_ph_t_nt(function_cq,Gauss_weights_reference_1D,Gauss_nodes_reference_1D,boundary_nodes_coodinate,vertices,basis_type,beta,basis_test_der_x,basis_test_der_y,2,tangential_section(1,1),t);    
         b(Tb_test(beta,n),1)=b(Tb_test(beta,n),1)+w1;
         
         w2=Gauss_quad_for_line_test_ph_t_nt(function_cq,Gauss_weights_reference_1D,Gauss_nodes_reference_1D,boundary_nodes_coodinate,vertices,basis_type,beta,basis_test_der_x,basis_test_der_y,1,normal_section(2,1),t)+...
            Gauss_quad_for_line_test_ph_t_nt(function_cq,Gauss_weights_reference_1D,Gauss_nodes_reference_1D,boundary_nodes_coodinate,vertices,basis_type,beta,basis_test_der_x,basis_test_der_y,2,tangential_section(2,1),t);             
         b(Nb+Tb_test(beta,n),1)=b(Nb+Tb_test(beta,n),1)+w2;         
      end
      
      for alph=1:Nlb_trial
          for beta=1:Nlb_test
              R1= Gauss_quad_for_line_trial_test_rh_t_nt(function_Robin_cr,Gauss_weights_reference_1D,Gauss_nodes_reference_1D,boundary_nodes_coodinate,vertices,basis_type,alph,basis_trial_der_x,basis_trial_der_y,beta,basis_test_der_x,basis_test_der_y,normal_section(1,1),normal_section(1,1),t)+...
                  Gauss_quad_for_line_trial_test_rh_t_nt(function_Robin_cr,Gauss_weights_reference_1D,Gauss_nodes_reference_1D,boundary_nodes_coodinate,vertices,basis_type,alph,basis_trial_der_x,basis_trial_der_y,beta,basis_test_der_x,basis_test_der_y,tangential_section(1,1),tangential_section(1,1),t);
              A(Tb_test(beta,n),Tb_trial(alph,n))= A(Tb_test(beta,n),Tb_trial(alph,n))+R1;

              R2= Gauss_quad_for_line_trial_test_rh_t_nt(function_Robin_cr,Gauss_weights_reference_1D,Gauss_nodes_reference_1D,boundary_nodes_coodinate,vertices,basis_type,alph,basis_trial_der_x,basis_trial_der_y,beta,basis_test_der_x,basis_test_der_y,normal_section(2,1),normal_section(1,1),t)+...
                  Gauss_quad_for_line_trial_test_rh_t_nt(function_Robin_cr,Gauss_weights_reference_1D,Gauss_nodes_reference_1D,boundary_nodes_coodinate,vertices,basis_type,alph,basis_trial_der_x,basis_trial_der_y,beta,basis_test_der_x,basis_test_der_y,tangential_section(2,1),tangential_section(1,1),t);              
              A(Tb_test(beta,n),Nb+Tb_trial(alph,n))= A(Tb_test(beta,n),Nb+Tb_trial(alph,n))+R2;
              
              R3= Gauss_quad_for_line_trial_test_rh_t_nt(function_Robin_cr,Gauss_weights_reference_1D,Gauss_nodes_reference_1D,boundary_nodes_coodinate,vertices,basis_type,alph,basis_trial_der_x,basis_trial_der_y,beta,basis_test_der_x,basis_test_der_y,normal_section(1,1),normal_section(2,1),t)+...
                  Gauss_quad_for_line_trial_test_rh_t_nt(function_Robin_cr,Gauss_weights_reference_1D,Gauss_nodes_reference_1D,boundary_nodes_coodinate,vertices,basis_type,alph,basis_trial_der_x,basis_trial_der_y,beta,basis_test_der_x,basis_test_der_y,tangential_section(1,1),tangential_section(2,1),t);
              A(Nb+Tb_test(beta,n),Tb_trial(alph,n))= A(Nb+Tb_test(beta,n),Tb_trial(alph,n))+R3;              

              R4= Gauss_quad_for_line_trial_test_rh_t_nt(function_Robin_cr,Gauss_weights_reference_1D,Gauss_nodes_reference_1D,boundary_nodes_coodinate,vertices,basis_type,alph,basis_trial_der_x,basis_trial_der_y,beta,basis_test_der_x,basis_test_der_y,normal_section(2,1),normal_section(2,1),t)+...
                  Gauss_quad_for_line_trial_test_rh_t_nt(function_Robin_cr,Gauss_weights_reference_1D,Gauss_nodes_reference_1D,boundary_nodes_coodinate,vertices,basis_type,alph,basis_trial_der_x,basis_trial_der_y,beta,basis_test_der_x,basis_test_der_y,tangential_section(2,1),tangential_section(2,1),t);                             
              A(Nb+Tb_test(beta,n),Nb+Tb_trial(alph,n))= A(Nb+Tb_test(beta,n),Nb+Tb_trial(alph,n))+R4;              
          end
      end      
    end
end


