function b=treat_boundary_Neumann_u_t_nt(function_cp,b,boundary_edges,P,T,Gauss_nodes_number,...
                                     Nlb,Pb_trial,Tb,basis_type,basis_der_x,basis_der_y,t)
Nb=size(Pb_trial,2);
nbe=size(boundary_edges,2);%d�ڶ���߽������
for k=1:nbe
    if(boundary_edges(1,k)==-2)
        
        n=boundary_edges(3,k);%ȷ���߽�����ĸ��Ԫ
        vertices=P(:,T(:,n));%ȡ����������,����ȷ�����Ե�Ԫ�Ͼֲ���������ȷ��������
        boundary_nodes_coodinate=P(:,boundary_edges(4:5,k));%ȡ�߽�߽ڵ����꣬�������߻���
        boundary_edges_normal_section=boundary_edges(6:7,k);
        boundary_edges_tangential_section=boundary_edges(8:9,k);
        [Gauss_weights_reference_1D,Gauss_nodes_reference_1D]=generate_Gauss_reference_1D(Gauss_nodes_number);
        
      for beta=1:Nlb 

           v1=Gauss_quad_for_line_test_ph_t_nt(function_cp,Gauss_weights_reference_1D,Gauss_nodes_reference_1D,boundary_nodes_coodinate,vertices,basis_type,beta,basis_der_x,basis_der_y,1,boundary_edges_normal_section(1,1),t)+...    
              Gauss_quad_for_line_test_ph_t_nt(function_cp,Gauss_weights_reference_1D,Gauss_nodes_reference_1D,boundary_nodes_coodinate,vertices,basis_type,beta,basis_der_x,basis_der_y,2,boundary_edges_tangential_section(1,1),t);
           b(Tb(beta,n),1)=b(Tb(beta,n),1)+v1; %��
           
           v2=Gauss_quad_for_line_test_ph_t_nt(function_cp,Gauss_weights_reference_1D,Gauss_nodes_reference_1D,boundary_nodes_coodinate,vertices,basis_type,beta,basis_der_x,basis_der_y,1,boundary_edges_normal_section(2,1),t)+...    
              Gauss_quad_for_line_test_ph_t_nt(function_cp,Gauss_weights_reference_1D,Gauss_nodes_reference_1D,boundary_nodes_coodinate,vertices,basis_type,beta,basis_der_x,basis_der_y,2,boundary_edges_tangential_section(2,1),t);                     
           b(Nb+Tb(beta,n),1)=b(Nb+Tb(beta,n),1)+v2;
           
      end
      
    end
end




