function result=function_Dirichlet_s_t(x,y,t)

%result=exact_order_solution_2D_s_t(0,0,x,y,t);    
result=1;%0.308;
