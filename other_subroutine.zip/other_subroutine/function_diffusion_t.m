function result=function_diffusion_t(x,y,t)
result=10^(-2);%=3.15*10^(-2);
% result=exp(x+y);
