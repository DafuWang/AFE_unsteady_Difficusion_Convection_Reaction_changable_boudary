function result=function_convection_y_t(x,y,t)
result=0;

% result=-y;
% ԭ����cos(x+y);
% result=cos(x+y);
% result=x;