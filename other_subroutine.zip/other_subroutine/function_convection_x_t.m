function result=function_convection_x_t(x,y,t)
result=0;%0.3;
% result=x;
% ԭ����sin(x+y);
% result=-y;
% result=sin(x+y);