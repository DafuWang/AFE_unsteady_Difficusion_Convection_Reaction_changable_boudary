function result=function_f_t(x,y,t)
result=0;
%  result=exp(x+y+t)-4*exp(x+y)*exp(x+y+t)+sin(x+y).*exp(x+y+t)+cos(x+y).*exp(x+y+t)+cos(x.*y).*exp(x+y+t);