function result=function_mass_coef(x,y,t)
result=1;



