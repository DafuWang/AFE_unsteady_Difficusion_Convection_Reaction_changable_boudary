function result=function_reaction_t(x,y,t)
 result=0;%3.15;
